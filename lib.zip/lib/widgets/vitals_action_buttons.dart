import 'package:flutter/material.dart';

class VitalsActionButtons extends StatelessWidget {
  final String patientId;
  final VoidCallback? onAddVital;
  final VoidCallback? onViewGraph;

  const VitalsActionButtons({
    super.key,
    required this.patientId,
    this.onAddVital,
    this.onViewGraph,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ElevatedButton.icon(
          icon: const Icon(Icons.add),
          label: const Text('Add Vitals'),
          onPressed: onAddVital ?? () {},
        ),
        const SizedBox(width: 12),
        OutlinedButton.icon(
          icon: const Icon(Icons.show_chart),
          label: const Text('View Graph'),
          onPressed: onViewGraph ?? () {},
        ),
      ],
    );
  }
}
