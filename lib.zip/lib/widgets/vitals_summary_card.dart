import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/vitals_model.dart';

class VitalsSummaryCard extends StatelessWidget {
  final VitalsModel vitals;

  const VitalsSummaryCard({super.key, required this.vitals});

  @override
  Widget build(BuildContext context) {
    final formatter = DateFormat('MMM d, h:mm a');
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(formatter.format(vitals.recordedAt),
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text('Pulse: ${vitals.pulse} bpm'),
            Text('BP: ${vitals.systolic}/${vitals.diastolic} mmHg'),
            Text('Temp: ${vitals.temperature.toStringAsFixed(1)} °F'),
            Text('Resp: ${vitals.respirationRate} bpm'),
            Text('O₂: ${vitals.oxygenSaturation}%'),
            const SizedBox(height: 8),
            Text('Logged by: ${vitals.recordedBy}',
                style: Theme.of(context).textTheme.labelSmall),
          ],
        ),
      ),
    );
  }
}
