import 'package:flutter/material.dart';
import 'package:nurse_os/models/vitals_model.dart';
import 'package:nurse_os/widgets/vitals_summary_card.dart';

class VitalsCarousel extends StatelessWidget {
  final List<VitalsModel> vitals;

  const VitalsCarousel({super.key, required this.vitals});

  @override
  Widget build(BuildContext context) {
    if (vitals.length == 1) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: VitalsSummaryCard(vitals: vitals.first),
      );
    }

    return SizedBox(
      height: 220,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: vitals.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) {
          return SizedBox(
            width: 260,
            child: VitalsSummaryCard(vitals: vitals[i]),
          );
        },
      ),
    );
  }
}
