// lib/state/patient_repository_provider.dart

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../repositories/patient_repository.dart';
import '../services/in_memory_patient_repository.dart';

final patientRepositoryProvider = Provider<PatientRepository>((ref) {
  return InMemoryPatientRepository(); // Replace with FirebasePatientRepository later
});
