import '../models/patient_model.dart';
import '../models/vitals_model.dart';
import '../models/sentiment_note_model.dart';
import '../models/shift_note_model.dart';
import '../mock_data/mock_constants.dart';

class MockScenarioBuilder {
  static PatientModel stablePatient({required String uid}) {
    return PatientModel(
      uid: uid,
      displayName: "Liam Smith",
      assignedNurses: [mockNurseAnaId],
      riskFlags: ["low"],
      vitals: [
        VitalsEntry(
          patientId: uid,
          timestamp: DateTime.now().subtract(Duration(hours: 2)),
          bp: "120/80",
          pulse: 72,
        )
      ],
      sentimentNotes: [
        SentimentNote(
          patientId: uid,
          content: "Calm and cooperative",
          sentimentTag: "neutral",
          wasAiGenerated: false,
          createdAt: DateTime.now().subtract(Duration(hours: 1)),
          createdBy: mockNurseAnaId,
        )
      ],
    );
  }

  static ShiftNote gptGeneratedShiftNote({required String patientId}) {
    return ShiftNote(
      patientId: patientId,
      content: "Patient remained stable during morning shift. Vitals within normal limits.",
      generated: true,
      generatedBy: "GPT",
      createdBy: mockNurseAnaId,
      createdAt: DateTime.now(),
    );
  }
}
