// Shared constants for mock UIDs and display names

const mockNurseAnaId = "nurse_ana";
const mockNurseJamalId = "nurse_jamal";

const mockPatientLiamId = "patient_liam";
const mockPatientZaraId = "patient_zara";

const mockShiftIdMorning = "shift_morning";
const mockShiftIdEvening = "shift_evening";
