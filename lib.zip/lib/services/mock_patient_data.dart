
import 'package:nurse_os/models/patient_model.dart';
import 'package:nurse_os/utils/risk_utils.dart';

final mockPatients = [
  PatientModel(
    id: '4',
    firstName: 'Carlos',
    lastName: 'Martinez',
    age: 81,
    roomNumber: '411D',
    diagnosis: 'CHF',
    tags: ['Oxygen', 'Daily Weights'],
    riskLevel: determineRiskLevel('CHF'),
    pronouns: 'he/him',
    photoUrl: 'https://i.pravatar.cc/150?img=18',
    admittedAt: DateTime.now().subtract(Duration(days: 5)),
  ),
  PatientModel(
    id: '1',
    firstName: 'Alice',
    lastName: 'Nguyen',
    age: 72,
    roomNumber: '302B',
    diagnosis: 'Hypertension',
    tags: ['Fall Risk', 'Isolation'],
    riskLevel: RiskLevel.high,
    pronouns: 'she/her',
    photoUrl: 'https://i.pravatar.cc/150?img=12',
    admittedAt: DateTime.now().subtract(Duration(days: 2)),
  ),
  PatientModel(
    id: '2',
    firstName: 'Jamal',
    lastName: 'Thompson',
    age: 66,
    roomNumber: '110A',
    diagnosis: 'Post-op recovery',
    tags: ['Dietary Restrictions'],
    riskLevel: determineRiskLevel('Post-op recovery'),
    pronouns: 'he/him',
    photoUrl: 'https://i.pravatar.cc/150?img=14',
    admittedAt: DateTime.now().subtract(Duration(hours: 18)),
  ),
  PatientModel(
    id: '3',
    firstName: 'Rina',
    lastName: 'Patel',
    age: 54,
    roomNumber: '208C',
    diagnosis: 'Asthma',
    tags: ['Inhaler', 'No Latex'],
    riskLevel: determineRiskLevel('Asthma'),
    pronouns: 'she/her',
    photoUrl: 'https://i.pravatar.cc/150?img=16',
    admittedAt: DateTime.now().subtract(Duration(days: 1, hours: 3)),
  ),

];
