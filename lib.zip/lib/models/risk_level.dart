enum RiskLevel {
  stable,
  moderate,
  high,
}
