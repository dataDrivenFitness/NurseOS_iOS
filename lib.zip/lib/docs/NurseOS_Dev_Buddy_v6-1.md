### 🔁 Development Support Flow (Addendum)

- Enforce use of `MockScenarioBuilder` and `mock_constants.dart` in all new mock files
- Refactor legacy mock data to use composable scenarios
- When scaffolding new features, generate test scenarios first, then data
